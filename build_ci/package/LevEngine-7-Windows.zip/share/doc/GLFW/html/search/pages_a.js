var searchData=
[
  ['damage_20and_20refresh_0',['Window damage and refresh',['../window_guide.html#window_refresh',1,'']]],
  ['decorations_1',['Wayland libdecor decorations',['../news.html#wayland_libdecor_decorations',1,'']]],
  ['default_20values_2',['default values',['../intro_guide.html#init_hints_values',1,'Supported and default values'],['../window_guide.html#window_hints_values',1,'Supported and default values']]],
  ['demand_3',['Joystick support is initialized on demand',['../news.html#joystick_init_caveat',1,'']]],
  ['dependencies_4',['Installing dependencies',['../compile_guide.html#compile_deps',1,'']]],
  ['dependencies_20for_20wayland_20and_20x11_5',['Dependencies for Wayland and X11',['../compile_guide.html#compile_deps_wayland',1,'']]],
  ['dependency_20has_20been_20removed_6',['macOS CoreVideo dependency has been removed',['../news.html#corevideo_caveat',1,'']]],
  ['deprecated_7',['deprecated',['../news.html#mingw_deprecated',1,'Original MinGW support is deprecated'],['../news.html#yosemite_deprecated',1,'OS X Yosemite support is deprecated'],['../news.html#winxp_deprecated',1,'Windows XP and Vista support is deprecated']]],
  ['deprecated_20list_8',['Deprecated List',['../deprecated.html',1,'']]],
  ['deprecations_9',['Deprecations',['../news.html#deprecations',1,'']]],
  ['destruction_10',['destruction',['../input_guide.html#cursor_destruction',1,'Cursor destruction'],['../window_guide.html#window_destruction',1,'Window destruction']]],
  ['disabled_20when_20built_20as_20a_20subproject_11',['Tests and examples are disabled when built as a subproject',['../news.html#standalone_caveat',1,'']]],
  ['documentation_20generation_20requires_20doxygen_201_209_208_20or_20later_12',['Documentation generation requires Doxygen 1.9.8 or later',['../news.html#docs_target_caveat',1,'']]],
  ['doxygen_201_209_208_20or_20later_13',['Documentation generation requires Doxygen 1.9.8 or later',['../news.html#docs_target_caveat',1,'']]],
  ['drop_20input_14',['Path drop input',['../input_guide.html#path_drop',1,'']]],
  ['dwm_20transparency_15',['Windows 7 framebuffer transparency requires DWM transparency',['../news.html#win7_framebuffer_caveat',1,'']]]
];
